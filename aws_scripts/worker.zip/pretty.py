#!/usr/bin/env python3

def red(s):
    return f"\033[1;31m{s}\033[0m"

def green(s):
    return f"\033[1;32m{s}\033[0m"

def yellow(s):
    return f"\033[1;33m{s}\033[0m"

def blue(s):
    return f"\033[1;34m{s}\033[0m"

def purple(s):
    return f"\033[1;35m{s}\033[0m"

def cyan(s):
    return f"\033[1;36m{s}\033[0m"
